# 디스코드 문의 티켓 & 서버 차단 봇

## 기능
1. **!연락설정**: 문의 티켓 생성 버튼 패널을 발송합니다 (관리자 전용).
2. **!로그설정 <#채널>**: 티켓 생성 및 종료 로그가 전송될 채널을 설정합니다.
3. **티켓 시스템**: 버튼을 눌러 개인 문의 채널을 생성하고 관리할 수 있습니다. 생성/종료 시 로그 채널로 알림이 전송됩니다.
4. **!섭차 <아이디/멘션>**: 대상을 즉시 서버에서 차단합니다.

## 디스호스트(Dishost) 호스팅 방법
1. [Discord Developer Portal](https://discord.com/developers/applications)에서 봇을 생성하고 **TOKEN**을 복사합니다.
2. **Privileged Gateway Intents** 설정에서 `Presence Intent`, `Server Members Intent`, `Message Content Intent`를 모두 활성화합니다.
3. 디스호스트 대시보드에서 새로운 프로젝트를 생성합니다.
4. 모든 파일을 업로드합니다.
5. `.env` 파일의 `YOUR_DISCORD_BOT_TOKEN_HERE` 부분을 실제 봇 토큰으로 수정합니다.
6. `pnpm install` 또는 `npm install` 후 `npm start`로 실행합니다.

## 주의사항
- 봇이 사용자를 차단하려면 봇의 역할(Role)이 차단하려는 사용자보다 높아야 합니다.
- 봇에게 `서버 차단(Ban Members)`, `채널 관리(Manage Channels)` 권한이 있어야 합니다.
