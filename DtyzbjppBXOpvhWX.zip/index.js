const { 
    Client, 
    GatewayIntentBits, 
    Partials, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    ChannelType, 
    PermissionFlagsBits,
    ActivityType
} = require('discord.js');
require('dotenv').config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction],
});

const PREFIX = '!';
let logChannelId = null;

client.once('ready', () => {
    console.log(`${client.user.tag} 봇이 준비되었습니다!`);
    client.user.setActivity('!도움말을 입력하세요', { type: ActivityType.Playing });
});

client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;

    // !도움말 명령어
    if (message.content === `${PREFIX}도움말`) {
        const helpEmbed = new EmbedBuilder()
            .setTitle('🤖 봇 도움말')
            .setDescription('사용 가능한 명령어 목록입니다.')
            .addFields(
                { name: `🎫 티켓 관련`, value: `\`!연락설정\` - 티켓 생성 패널 발송\n\`!로그설정 <#채널>\` - 티켓 로그 채널 설정`, inline: false },
                { name: `🛠️ 관리 기능`, value: `\`!섭차 <아이디/멘션>\` - 서버에서 차단\n\`!상태메시지 <내용>\` - 봇의 활동 상태 변경`, inline: false },
                { name: `❓ 기타`, value: `\`!도움말\` - 지금 보시는 도움말 출력`, inline: false }
            )
            .setColor(0x5865F2)
            .setTimestamp();
        
        message.reply({ embeds: [helpEmbed] });
    }

    // !상태메시지 명령어
    if (message.content.startsWith(`${PREFIX}상태메시지`)) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) return;
        
        const args = message.content.split(' ').slice(1).join(' ');
        if (!args) return message.reply('변경할 상태 메시지 내용을 입력해주세요.');

        client.user.setActivity(args, { type: ActivityType.Playing });
        message.reply(`봇의 상태 메시지가 \`${args}\`(으)로 변경되었습니다.`);
    }

    // !섭차 명령어
    if (message.content.startsWith(`${PREFIX}섭차`)) {
        if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return message.reply('권한이 없습니다.');
        }

        const args = message.content.split(' ');
        if (args.length < 2) return message.reply('사용법: !섭차 <아이디 또는 멘션>');

        const target = message.mentions.members.first() || await message.guild.members.fetch(args[1]).catch(() => null);

        if (!target) return message.reply('사용자를 찾을 수 없습니다.');
        if (!target.bannable) return message.reply('해당 사용자를 차단할 수 없습니다.');

        try {
            await target.ban({ reason: '관리자에 의한 서버 차단' });
            const banEmbed = new EmbedBuilder()
                .setTitle('서버 차단 완료')
                .setDescription(`${target.user.tag}님이 서버에서 차단되었습니다.`)
                .setColor(0xFF0000)
                .setTimestamp();
            message.channel.send({ embeds: [banEmbed] });
        } catch (error) {
            console.error(error);
            message.reply('차단 처리 중 오류가 발생했습니다.');
        }
    }

    // !로그설정 명령어
    if (message.content.startsWith(`${PREFIX}로그설정`)) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) return;
        
        const channel = message.mentions.channels.first() || message.channel;
        logChannelId = channel.id;
        
        message.reply(`로그 채널이 ${channel}로 설정되었습니다.`);
    }

    // !연락설정 명령어
    if (message.content === `${PREFIX}연락설정`) {
        if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) return;

        const embed = new EmbedBuilder()
            .setTitle('문의 및 연락 패널')
            .setDescription('도움이 필요하시거나 문의사항이 있다면 아래 버튼을 눌러주세요.')
            .setColor(0x5865F2)
            .setFooter({ text: '문의 티켓 시스템' });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('create_ticket')
                .setLabel('티켓 생성')
                .setStyle(ButtonStyle.Success)
                .setEmoji('📩')
        );

        message.channel.send({ embeds: [embed], components: [row] });
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'create_ticket') {
        const channelName = `ticket-${interaction.user.username}`;
        const existingChannel = interaction.guild.channels.cache.find(c => c.name === channelName.toLowerCase());
        
        if (existingChannel) {
            return interaction.reply({ content: '이미 생성된 티켓이 있습니다.', ephemeral: true });
        }

        const ticketChannel = await interaction.guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            permissionOverwrites: [
                { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            ],
        });

        const embed = new EmbedBuilder()
            .setTitle('문의 접수 완료')
            .setDescription(`${interaction.user}님, 문의 내용을 남겨주시면 관리자가 답변드리겠습니다.`)
            .setColor(0x2F3136)
            .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('티켓 닫기')
                .setStyle(ButtonStyle.Danger)
                .setEmoji('🔒')
        );

        await ticketChannel.send({ content: `${interaction.user}님 환영합니다.`, embeds: [embed], components: [row] });
        await interaction.reply({ content: `티켓이 생성되었습니다: ${ticketChannel}`, ephemeral: true });

        if (logChannelId) {
            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🎫 티켓 생성 로그')
                    .addFields(
                        { name: '사용자', value: `${interaction.user.tag}`, inline: true },
                        { name: '채널', value: `${ticketChannel.name}`, inline: true }
                    )
                    .setColor(0x57F287)
                    .setTimestamp();
                logChannel.send({ embeds: [logEmbed] });
            }
        }
    }

    if (interaction.customId === 'close_ticket') {
        await interaction.reply('티켓을 종료합니다. 잠시 후 채널이 삭제됩니다.');

        if (logChannelId) {
            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle('🔒 티켓 종료 로그')
                    .addFields(
                        { name: '종료자', value: `${interaction.user.tag}`, inline: true },
                        { name: '채널명', value: `${interaction.channel.name}`, inline: true }
                    )
                    .setColor(0xED4245)
                    .setTimestamp();
                logChannel.send({ embeds: [logEmbed] });
            }
        }

        setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
    }
});

client.login(process.env.TOKEN);
